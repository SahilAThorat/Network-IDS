/// helper for tests
pub mod common;
/// gunzip tests
pub mod gunzip;
/// hybrid tests
pub mod hybrid;
/// main tests
pub mod main;
