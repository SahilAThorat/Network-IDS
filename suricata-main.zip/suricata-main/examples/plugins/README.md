# Example Plugins

## c-json-filetype

An example plugin of an EVE/JSON filetype plugin. This type of plugin
is useful if you want to send EVE output to custom destinations.

## ci-capture

A minimal capture plugin that can be used as a template, but also used
for testing capture plugin loading and registration in CI.

## altemplate

An app-layer template plugin with logging and detection.
Most code copied from rust/src/applayertemplate
