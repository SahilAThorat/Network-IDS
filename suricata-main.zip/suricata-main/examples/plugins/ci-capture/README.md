# Minimal Capture Plugin for CI

